#encoding: utf-8
"""
@project = FtpTools
@file = __init__.py
@function = 
@author = Cindy
@create_time = 2018/6/15 13:26
@python_version = 3.x
"""
